import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'zv-wizard',
  templateUrl: './wizard.component.html',
  styleUrls: ['./wizard.component.sass']
})
export class WizardComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
