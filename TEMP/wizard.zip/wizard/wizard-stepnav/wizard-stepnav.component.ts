import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'zv-wizard-stepnav',
  templateUrl: './wizard-stepnav.component.html',
  styleUrls: ['./wizard-stepnav.component.sass']
})
export class WizardStepnavComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
